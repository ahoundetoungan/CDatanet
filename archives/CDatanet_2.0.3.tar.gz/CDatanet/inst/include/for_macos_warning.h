#include <RcppArmadillo.h> 
#define NDEBUG 
#include <RcppEigen.h>
